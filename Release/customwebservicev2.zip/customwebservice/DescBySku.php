<?php
/**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

/**
 * @deprecated 1.5.0.1
 */
define('_CUSTOMIZE_FILE_', 0);
/**
 * @deprecated 1.5.0.1
 */
define('_CUSTOMIZE_TEXTFIELD_', 1);

use PrestaShop\PrestaShop\Adapter\ServiceLocator;

class DescBySkuCore extends ObjectModel
{
    public $quantity;
    public $price;
    public $id_manufacturer;
    public $manufacturer_name;
    public $id_category_default;
    public $id_default_image;
    public $reference;
    public $description;
    public $description_short;
    public $width = 0;
    public $height = 0;
    public $depth = 0;
    public $weight = 0;
    const STATE_TEMP = 0;
    const STATE_SAVED = 1;

    public static $definition = array(
        'table' => 'product',
        'primary' => 'id_product',
        'fields' => array(
            'reference' =>   array('type' => self::TYPE_STRING),
            'price'     =>   array('type' => self::TYPE_FLOAT),
            'id_manufacturer'     =>   array('type' => self::TYPE_FLOAT),
            'manufacturer_name' => array('type' => self::TYPE_STRING),
            'name' =>       array('type' => self::TYPE_STRING),
            'description' =>       array('type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'),
            'description_short' => array('type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'),
            'width' =>                        array('type' => self::TYPE_FLOAT, 'validate' => 'isUnsignedFloat'),
            'height' =>                    array('type' => self::TYPE_FLOAT, 'validate' => 'isUnsignedFloat'),
            'depth' =>                        array('type' => self::TYPE_FLOAT, 'validate' => 'isUnsignedFloat'),
            'weight' =>                    array('type' => self::TYPE_FLOAT, 'validate' => 'isUnsignedFloat'),
        ),
        'associations' => array(
            
        ),
    );


    protected $webserviceParameters = array(
        'objectNodeNames' => 'products',
        'fields' => array(
            'name' => array('getter' => 'getWsName'),
            'id_default_image' => array('getter' => 'getCoverWs'),
            'default_image_url' => array('getter' => 'getWsDefaultImageURL'),
            'manufacturer_name' => array('getter' => 'getWsManufacturerName'),
            'description' => array('getter' => 'getWsDescription'),
            'description_short' => array('getter' => 'getWsDescriptionShort'),
            'stock' => array('getter' => 'getWsQuantityInShop'),
			'tax' => array('getter' => 'getWsTax'),
        ),
        'associations' => array(
            'warehouses' => array(
                'resource' => 'warehouse',
                'display' => 'full',
                'fields' => array(
                    'id' => array('required' => true),
                    'name' => array('required' => true),
                    'quantity' => array('required' => true),
                )
            ),
            'categories' => array(
                'resource' => 'category',
                'fields' => array(
                    'id' => array('required' => true),
                    'name' => array('required' => true),
                    'description' => array('required' => true),
                )
            ),
            'images' => array(
                'resource' => 'image',
                'fields' => array(
                    'id' => array('required' => true),
                    'url' => array('required' => true),
                )
            ),
            'variations' => array(
                'resource' => 'variation',
                'fields' => array(
                    'id_variation' => array('required' => true),
                    'attributes' => array('required' => true),
                    'price' => array('required' => true),
                    'quantity' => array('required' => true),
                    'reference' => array('required' => true),
                    'weight' => array('required' => true)
                )
            ),
            'special_prices' => array(
                'resource' => 'special_price',
                'fields' => array(
                    'id_special_price' => array('required' => true),
                    'id_currency' => array('required' => true),
                    'id_country' => array('required' => true),
                    'id_customer' => array('required' => true),
                    'id_product_variation' => array('required' => true),
                    'price' => array('required' => true),
                    'from_quantity' => array('required' => true),
                    'reduction' => array('required' => true),
                    'reduction_tax' => array('required' => true),
                    'reduction_type' => array('required' => true),
                    'start_date' => array('required' => true),
                    'end_date' => array('required' => true),
                    'price' => array('required' => true)
                )
            ),
        ),
    );

    const CUSTOMIZE_FILE = 0;
    const CUSTOMIZE_TEXTFIELD = 1;

    public function __construct($id_product = null, $full = false, $id_lang = null, $id_shop = null, Context $context = null)
    {
        parent::__construct($id_product, $id_lang, $id_shop);
        if ($full && $this->id) {
            if (!$context) {
                $context = Context::getContext();
            }
        }
    }

    public function getWsSpecialPrices()
    {
        $result =  Db::getInstance()->executeS('
            SELECT  pa.`id_specific_price` AS id_special_price,
                    pa.`id_currency` AS id_currency,
                    pa.`id_country` AS id_country,
                    pa.`id_customer` AS id_customer,
                    pa.`id_product_attribute` AS id_product_variation,
                    pa.`price` AS price,
                    pa.`from_quantity` AS from_quantity,
                    pa.`reduction` AS reduction,
                    pa.`reduction_tax` AS reduction_tax,
                    pa.`reduction_type` AS reduction_type,
                    pa.`from` AS start_date,
                    pa.`to` AS end_date
            FROM `'._DB_PREFIX_.'specific_price` pa
            WHERE pa.`id_product` = '.(int)$this->id
        );

        return $result;
    }

    public function getWsVariations()
    {
        $result =  Db::getInstance()->executeS('
            SELECT  pa.`id_product_attribute` AS id_variation,
                    pa.`quantity` AS quantity,
                    pa.`weight` as weight,
                    pa.`price` AS price,
                    pa.`reference` AS reference,
                    concat("[",group_concat(concat("{\'id_attribute\': ",a.`id_attribute`,", \'type\': ",agl.`name`," , \'name\': ",al.`name`,"}")),"]") as attributes

            FROM `'._DB_PREFIX_.'product_attribute` pa
            LEFT JOIN `'._DB_PREFIX_.'product_attribute_combination` pac ON pa.id_product_attribute = pac.id_product_attribute
            INNER JOIN `'._DB_PREFIX_.'attribute` a ON a.id_attribute = pac.id_attribute
            INNER JOIN `'._DB_PREFIX_.'attribute_lang` al ON al.id_attribute = a.id_attribute
            AND al.id_lang = '.(int)Context::getContext()->language->id.'
            INNER JOIN `'._DB_PREFIX_.'attribute_group` ag ON ag.id_attribute_group = a.id_attribute_group
            INNER JOIN `'._DB_PREFIX_.'attribute_group_lang` agl ON agl.id_attribute_group = ag.id_attribute_group
            AND agl.id_lang = '.(int)Context::getContext()->language->id.'
            WHERE pa.`id_product` = '.(int)$this->id.'
            GROUP BY id_variation'
        );

        return $result;
    }

    public function getWsWarehouses()
    {
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT w.`id_warehouse` AS id, w.`name` AS name, s.physical_quantity as quantity
            FROM `'._DB_PREFIX_.'warehouse` w
            inner JOIN `'._DB_PREFIX_.'stock` s ON (w.id_warehouse = s.id_warehouse)
            inner JOIN `'._DB_PREFIX_.'product` p ON (s.id_product = p.id_product)
            WHERE p.`id_product` = '.(int)$this->id
        );
        return $result;
    }
    
    public function getWsCategories()
    {
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT cp.`id_category` AS id, cl.`name` as name, cl.`description` as description
            FROM `'._DB_PREFIX_.'category_product` cp
            LEFT JOIN `'._DB_PREFIX_.'category` c ON (c.id_category = cp.id_category)
            LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON (cl.id_category = cp.id_category)
            WHERE cp.`id_product` = '.(int)$this->id
        );
        return $result;
    }

    public function getWsTotalQuantity()
    {
        $result_in_shop = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT `quantity` AS quantity
            FROM `'._DB_PREFIX_.'stock_available`
            WHERE `id_product_attribute` = 0 AND `id_product` = '.(int)$this->id
        );
        $result_in_warehouse = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT SUM(`usable_quantity`) AS quantity
            FROM `'._DB_PREFIX_.'stock`
            WHERE `id_product` = '.(int)$this->id
        );

        return (int)$result_in_warehouse[0]['quantity'] + (int)$result_in_shop[0]['quantity'];
    }

    public function getWsImages()
    {
        $result =  Db::getInstance()->executeS('
        SELECT i.`id_image` as id
        FROM `'._DB_PREFIX_.'image` i
        '.Shop::addSqlAssociation('image', 'i').'
        WHERE i.`id_product` = '.(int)$this->id.'
        ORDER BY i.`position`');
        $link = new Link();
        foreach ($result as &$valor) {
            $valor['url'] = $link->getImageLink((string) $valor['id'],(string) $valor['id']);
        }

        return $result;
    }

    public function getCoverWs()
    {
        $result = $this->getCover($this->id);
        return $result['id_image'];
    }

    public static function getCover($id_product, Context $context = null)
    {
        if (!$context) {
            $context = Context::getContext();
        }
        $cache_id = 'Product::getCover_'.(int)$id_product.'-'.(int)$context->shop->id;
        if (!Cache::isStored($cache_id)) {
            $sql = 'SELECT image_shop.`id_image`
                    FROM `'._DB_PREFIX_.'image` i
                    '.Shop::addSqlAssociation('image', 'i').'
                    WHERE i.`id_product` = '.(int)$id_product.'
                    AND image_shop.`cover` = 1';
            $result = Db::getInstance()->getRow($sql);
            Cache::store($cache_id, $result);
            return $result;
        }
        return Cache::retrieve($cache_id);
    }

    public function getWsManufacturerName()
    {
        return Manufacturer::getNameById((int)$this->id_manufacturer);
    }


    public function getDescriptions(){
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT `description` AS description, `description_short` AS description_short, `name` AS name
            FROM `'._DB_PREFIX_.'product_lang`
            WHERE `id_lang` = '.(int)Context::getContext()->language->id.
            ' AND id_product = '.(int)$this->id.
            ' AND id_shop = '.(int)Context::getContext()->shop->id
        );
        return $result[0];
    }

    public function getWsDescription()
    {   
        return $this->getDescriptions()['description'];
    }

    public function getWsDescriptionShort()
    {
        return $this->getDescriptions()['description_short'];
    }

    public function getWsName()
    {
        return $this->getDescriptions()['name'];
    }

    public function getWsDefaultImageURL(){
        $link = new Link();
        $image_id = $this->getCoverWs();
        return $link->getImageLink((string) $image_id,(string) $image_id);
    }

    public function getWsQuantityInShop()
    {
        $result_in_shop = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT `quantity` AS quantity
            FROM `'._DB_PREFIX_.'stock_available`
            WHERE `id_product_attribute` = 0 AND `id_product` = '.(int)$this->id
        );

        return (int)$result_in_shop[0]['quantity'];
    }
	
	public function getWsTax()
    {
        $result_in_shop = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT trg.`name` AS name,
					t.`rate` AS rate,
					tr.`id_tax_rules_group` AS id_tax_rules_group,
					tr.`id_tax_rule` AS id_tax_rule,
					tr.`id_country` AS id_country,
					tr.`id_state` AS id_state,
					tr.`zipcode_from` AS zipcode_from,
					tr.`zipcode_to` AS zipcode_to,
					tr.`id_tax` AS id_tax,
					tr.`description` AS description
            FROM `'._DB_PREFIX_.'tax_rules_group` trg
			inner JOIN `'._DB_PREFIX_.'product` p ON (p.id_tax_rules_group = trg.id_tax_rules_group)
			inner JOIN `'._DB_PREFIX_.'tax_rule` tr ON (tr.id_tax_rules_group = trg.id_tax_rules_group)
			inner JOIN `'._DB_PREFIX_.'tax` t ON (t.id_tax = tr.id_tax)
            WHERE `id_product` = '.(int)$this->id
        );
		
		$json = array();
		foreach($result_in_shop as $value){
			$aux = array();
			foreach($value as $k => $v){
				array_push($aux, "'".$k."' : '".$v."'");
			}
			array_push($json, '{'.implode($aux,', ').'}');
		}

        return '[ '.implode($json,',').']';
    }

}
