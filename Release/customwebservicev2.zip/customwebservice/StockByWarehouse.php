<?php
/**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

/**
 * @deprecated 1.5.0.1
 */
define('_CUSTOMIZE_FILE_', 0);
/**
 * @deprecated 1.5.0.1
 */
define('_CUSTOMIZE_TEXTFIELD_', 1);

use PrestaShop\PrestaShop\Adapter\ServiceLocator;

class StockByWarehouseCore extends ObjectModel
{
    public $quantity = 0;
    public $price = 0;
    public $reference;

    const STATE_TEMP = 0;
    const STATE_SAVED = 1;

    public static $definition = array(
        'table' => 'product',
        'primary' => 'id_product',
        'fields' => array(
            'reference' =>   array('type' => self::TYPE_STRING),
            'price'     =>   array('type' => self::TYPE_FLOAT),
        )
    );


    protected $webserviceParameters = array(
        'objectNodeNames' => 'products',
        'fields' => array(
            'TotalQuantity' => array(
                'getter' => 'getWsTotalQuantity',
            ),
            'QuantityInShop' => array(
                'getter' => 'getWsQuantityInShop',
            ),
			'tax' => array(
                'getter' => 'getWsTax',
            ),
        ),
        'associations' => array(
            'warehouses' => array(
                'resource' => 'warehouse',
                'display' => 'full',
                'fields' => array(
                    'id' => array('required' => true),
                    'name' => array('required' => true),
                    'quantity' => array('required' => true),
                )
            ),
        ),
    );

    const CUSTOMIZE_FILE = 0;
    const CUSTOMIZE_TEXTFIELD = 1;

    public function __construct($id_product = null, $full = false, $id_lang = null, $id_shop = null, Context $context = null)
    {
        parent::__construct($id_product, $id_lang, $id_shop);
        if ($full && $this->id) {
            if (!$context) {
                $context = Context::getContext();
            }
        }
    }

    public function getWsWarehouses()
    {
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT w.`id_warehouse` AS id, w.`name` AS name, s.physical_quantity as quantity
            FROM `'._DB_PREFIX_.'warehouse` w
            inner JOIN `'._DB_PREFIX_.'stock` s ON (w.id_warehouse = s.id_warehouse)
            inner JOIN `'._DB_PREFIX_.'product` p ON (s.id_product = p.id_product)
            WHERE p.`id_product` = '.(int)$this->id
        );
        return $result;
    }

    public function getWsTotalQuantity()
    {
        $result_in_shop = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT `quantity` AS quantity
            FROM `'._DB_PREFIX_.'stock_available`
            WHERE `id_product_attribute` = 0 AND `id_product` = '.(int)$this->id
        );
        $result_in_warehouse = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT SUM(`usable_quantity`) AS quantity
            FROM `'._DB_PREFIX_.'stock`
            WHERE `id_product` = '.(int)$this->id
        );

        return (int)$result_in_warehouse[0]['quantity'] + (int)$result_in_shop[0]['quantity'];
    }

    public function getWsQuantityInShop()
    {
        $result_in_shop = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT `quantity` AS quantity
            FROM `'._DB_PREFIX_.'stock_available`
            WHERE `id_product_attribute` = 0 AND `id_product` = '.(int)$this->id
        );

        return $result_in_shop[0]['quantity'];
    }
	
	public function getWsTax()
    {
        $result_in_shop = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            'SELECT trg.`name` AS name,
					t.`rate` AS rate,
					tr.`id_tax_rules_group` AS id_tax_rules_group,
					tr.`id_tax_rule` AS id_tax_rule,
					tr.`id_country` AS id_country,
					tr.`id_state` AS id_state,
					tr.`zipcode_from` AS zipcode_from,
					tr.`zipcode_to` AS zipcode_to,
					tr.`id_tax` AS id_tax,
					tr.`description` AS description
            FROM `'._DB_PREFIX_.'tax_rules_group` trg
			inner JOIN `'._DB_PREFIX_.'product` p ON (p.id_tax_rules_group = trg.id_tax_rules_group)
			inner JOIN `'._DB_PREFIX_.'tax_rule` tr ON (tr.id_tax_rules_group = trg.id_tax_rules_group)
			inner JOIN `'._DB_PREFIX_.'tax` t ON (t.id_tax = tr.id_tax)
            WHERE `id_product` = '.(int)$this->id
        );
		
		$json = array();
		foreach($result_in_shop as $value){
			$aux = array();
			foreach($value as $k => $v){
				array_push($aux, "'".$k."' : '".$v."'");
			}
			array_push($json, '{'.implode($aux,', ').'}');
		}

        return '[ '.implode($json,',').']';
    }
	
}
