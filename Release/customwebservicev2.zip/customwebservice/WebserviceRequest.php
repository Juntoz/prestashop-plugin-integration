<?php
class WebserviceRequest extends WebserviceRequestCore 
{
    public static function getResources(){
        $resources = parent::getResources();
        $resources['stock_by_warehouse'] = array('description' => 'Loyalty management for products', 'class' => 'StockByWarehouse');
        $resources['description_by_sku'] = array('description' => 'Loyalty management for products', 'class' => 'DescBySku');
        $resources['attribute_stock'] = array('description' => 'Loyalty management for products', 'class' => 'AttributeStock');
        ksort($resources);
        return $resources;
    }

}